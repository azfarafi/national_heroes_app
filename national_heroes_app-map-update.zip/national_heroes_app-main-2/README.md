# Jejak Pahlawan

Aplikasi Flutter untuk menjelajahi, mencari, menambah, mengedit, dan menghapus kisah pahlawan nasional Indonesia. Data dan komentar tetap tersimpan di API PHP/MySQL yang ada di folder `backend/`.

## Yang baru

- Animasi pembuka menggunakan peta Indonesia dari gambar yang diberikan, berlatar transparan dan berwarna merah, dengan transisi lembut dan tombol **Lewati**.
- Tampilan responsif untuk ponsel dan desktop: palet krem, merah, putih, kartu bersudut lembut, dan tipografi sans tebal bergaya Inter Black. Font yang dibundel adalah ArchiveSans (DejaVu Sans), sehingga dapat dibaca tanpa unduhan font saat aplikasi berjalan.
- Pencarian langsung berdasarkan nama, daerah asal, masa hidup, dan biografi. Hasil diambil dari daftar API terbaru saat aplikasi dibuka, disegarkan, atau setelah penambahan/perubahan data.
- Pilihan tampilan kartu atau daftar, tarik layar untuk memuat ulang, dan pesan kondisi kosong atau gagal memuat.

## Menjalankan

1. Impor `backend/database.sql` ke MySQL, lalu jalankan API PHP dari `backend/api/`. Ikuti konfigurasi database di `backend/api/config.php`.
2. Jalankan `flutter pub get`.
3. Jalankan aplikasi dengan alamat API yang sesuai, misalnya:

```bash
flutter run --dart-define=API_URL=http://10.0.2.2:8080/pahlawan_api
```

`10.0.2.2` mengarah ke komputer host dari emulator Android. Di desktop/web lokal, gunakan `http://127.0.0.1:8080/pahlawan_api` jika API tersedia pada alamat tersebut. Perangkat fisik memerlukan alamat IP komputer pada jaringan yang sama. Foto hero dapat memakai path aset `assets/images/...` atau URL gambar.

Font ArchiveSans berasal dari DejaVu Fonts; lisensinya ada di `assets/fonts/LICENSE-DejaVu.txt`.

Peta bersumber dari gambar yang diberikan pengguna; kredit “Peta: Vemaps.com” ditampilkan pada layar pembuka dan beranda.
