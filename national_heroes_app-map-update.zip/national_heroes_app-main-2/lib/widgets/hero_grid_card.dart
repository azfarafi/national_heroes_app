import 'package:flutter/material.dart';
import '../theme/palette.dart';
import '../models/hero_model.dart';
import 'hero_image.dart';

class HeroGridCard extends StatelessWidget {
  final HeroModel hero;
  final VoidCallback onTap;
  const HeroGridCard({super.key, required this.hero, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Palette.paper,
    borderRadius: BorderRadius.circular(22),
    child: InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(22),
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), border: Border.all(color: Palette.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(flex: 6, child: ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(21)),
            child: ColoredBox(color: Palette.blush, child: HeroImage(path: hero.imagePath)))),
          Expanded(flex: 4, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(hero.name, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 16, height: 1.2, fontWeight: FontWeight.w900, color: Palette.ink)),
            const SizedBox(height: 6),
            Text(hero.origin, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Palette.red, fontSize: 12, fontWeight: FontWeight.w700)),
            const Spacer(),
            const Row(children: [Text('Baca kisah', style: TextStyle(color: Palette.muted, fontSize: 12, fontWeight: FontWeight.w700)),
              SizedBox(width: 4), Icon(Icons.arrow_forward_rounded, size: 15, color: Palette.red)]),
          ]))),
        ]),
      ),
    ),
  );
}
