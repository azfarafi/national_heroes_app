import 'package:flutter/material.dart';
import '../theme/palette.dart';
import '../models/hero_model.dart';
import 'hero_image.dart';

class HeroTile extends StatelessWidget {
  final HeroModel hero;
  final VoidCallback onTap;
  const HeroTile({super.key, required this.hero, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Palette.paper, borderRadius: BorderRadius.circular(18),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: Palette.line)),
      child: Row(children: [
        ClipRRect(borderRadius: BorderRadius.circular(12), child: SizedBox(width: 64, height: 64,
          child: ColoredBox(color: Palette.blush, child: HeroImage(path: hero.imagePath)))),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(hero.name, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Palette.ink)),
          const SizedBox(height: 3),
          Text(hero.origin, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Palette.muted, fontSize: 13)),
        ])),
        const Icon(Icons.arrow_forward_ios_rounded, size: 15, color: Palette.red),
        const SizedBox(width: 8),
      ]),
    )),
  );
}
