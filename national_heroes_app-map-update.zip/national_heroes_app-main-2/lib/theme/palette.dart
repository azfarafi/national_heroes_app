import 'package:flutter/material.dart';

class Palette {
  static const cream = Color(0xFFF8F3EA);
  static const paper = Color(0xFFFFFDF9);
  static const ink = Color(0xFF282321);
  static const muted = Color(0xFF6E6660);
  static const red = Color(0xFFB93736);
  static const darkRed = Color(0xFF922B2C);
  static const blush = Color(0xFFF5E6E1);
  static const line = Color(0xFFE8DDD1);
}
