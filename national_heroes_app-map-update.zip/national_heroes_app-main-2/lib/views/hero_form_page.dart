import 'package:flutter/material.dart';
import '../theme/palette.dart';
import '../models/hero_model.dart';
import '../services/api_service.dart';
import '../widgets/hero_image.dart';

/// Form untuk menambah pahlawan baru atau mengubah data pahlawan yang ada.
/// Mengembalikan [HeroModel] yang tersimpan melalui `Navigator.pop`.
class HeroFormPage extends StatefulWidget {
  final HeroModel? hero;

  const HeroFormPage({super.key, this.hero});

  @override
  State<HeroFormPage> createState() => _HeroFormPageState();
}

class _HeroFormPageState extends State<HeroFormPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _originController;
  late final TextEditingController _lifeTimeController;
  late final TextEditingController _descriptionController;
  late final TextEditingController _imageController;
  bool _saving = false;

  bool get _isEdit => widget.hero != null;

  @override
  void initState() {
    super.initState();
    final hero = widget.hero;
    _nameController = TextEditingController(text: hero?.name);
    _originController = TextEditingController(text: hero?.origin);
    _lifeTimeController = TextEditingController(text: hero?.lifeTime);
    _descriptionController = TextEditingController(text: hero?.description);
    _imageController = TextEditingController(text: hero?.imagePath);
    _imageController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _nameController.dispose();
    _originController.dispose();
    _lifeTimeController.dispose();
    _descriptionController.dispose();
    _imageController.dispose();
    super.dispose();
  }

  String? _required(String? value) =>
      (value == null || value.trim().isEmpty) ? 'Wajib diisi' : null;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final data = HeroModel(
      id: widget.hero?.id,
      name: _nameController.text.trim(),
      origin: _originController.text.trim(),
      lifeTime: _lifeTimeController.text.trim(),
      description: _descriptionController.text.trim(),
      imagePath: _imageController.text.trim(),
    );

    final api = ApiService.instance;
    final HeroModel saved;
    try {
      saved = _isEdit ? await api.updateHero(data) : await api.insertHero(data);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      return;
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isEdit
            ? 'Data ${saved.name} berhasil diperbarui'
            : '${saved.name} berhasil ditambahkan'),
      ),
    );
    Navigator.pop(context, saved);
  }

  InputDecoration _decoration(String label, {String? hint}) =>
      InputDecoration(labelText: label, hintText: hint);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(_isEdit ? 'Edit pahlawan' : 'Tambah pahlawan',
      style: const TextStyle(fontWeight: FontWeight.w900))),
    body: SafeArea(child: SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 50),
      child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 900),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: Palette.paper, borderRadius: BorderRadius.circular(26),
            border: Border.all(color: Palette.line)),
          child: Form(key: _formKey, child: LayoutBuilder(builder: (_, constraints) {
            final compact = constraints.maxWidth < 650;
            final preview = ClipRRect(borderRadius: BorderRadius.circular(18), child: SizedBox(
              width: compact ? double.infinity : 230, height: compact ? 210 : 280,
              child: ColoredBox(color: Palette.blush,
                child: HeroImage(path: _imageController.text.trim(), placeholder: 'Pratinjau foto'))));
            final fields = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(_isEdit ? 'Perbarui kisahnya' : 'Simpan kisah baru', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 7),
              const Text('Isi informasi berikut agar mudah ditemukan dalam arsip.',
                style: TextStyle(color: Palette.muted)),
              const SizedBox(height: 24),
              TextFormField(controller: _nameController, decoration: _decoration('Nama pahlawan'), validator: _required),
              const SizedBox(height: 15),
              TextFormField(controller: _originController, decoration: _decoration('Daerah asal', hint: 'Contoh: Blitar, Jawa Timur'), validator: _required),
              const SizedBox(height: 15),
              TextFormField(controller: _lifeTimeController, decoration: _decoration('Masa hidup', hint: 'Contoh: 1901–1970'), validator: _required),
              const SizedBox(height: 15),
              TextFormField(controller: _imageController, decoration: _decoration('Foto (path aset atau URL)', hint: 'assets/images/nama.jpg atau https://...')),
              const SizedBox(height: 15),
              TextFormField(controller: _descriptionController, decoration: _decoration('Biografi'), minLines: 4, maxLines: 8, validator: _required),
              const SizedBox(height: 22),
              Align(alignment: Alignment.centerRight, child: ElevatedButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_outlined),
                label: Text(_saving ? 'Menyimpan...' : _isEdit ? 'Simpan perubahan' : 'Tambah pahlawan'))),
            ]);
            return compact ? Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [preview, const SizedBox(height: 24), fields])
              : Row(crossAxisAlignment: CrossAxisAlignment.start,
                children: [preview, const SizedBox(width: 28), Expanded(child: fields)]);
          })),
        ),
      )),
    )),
  );
}
