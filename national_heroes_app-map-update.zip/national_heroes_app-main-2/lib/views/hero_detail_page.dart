import 'package:flutter/material.dart';
import '../theme/palette.dart';
import '../models/hero_model.dart';
import '../services/api_service.dart';
import '../widgets/comment_section.dart';
import '../widgets/hero_image.dart';
import 'hero_form_page.dart';

class HeroDetailPage extends StatefulWidget {
  final HeroModel hero;
  const HeroDetailPage({super.key, required this.hero});

  @override
  State<HeroDetailPage> createState() => _HeroDetailPageState();
}

class _HeroDetailPageState extends State<HeroDetailPage> {
  late HeroModel hero = widget.hero;

  Future<void> _edit() async {
    final updated = await Navigator.push<HeroModel>(context,
      MaterialPageRoute(builder: (_) => HeroFormPage(hero: hero)));
    if (updated != null && mounted) setState(() => hero = updated);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Hapus pahlawan?'),
      content: Text('Data “${hero.name}” beserta komentarnya akan terhapus.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus', style: TextStyle(color: Palette.red))),
      ],
    ));
    if (confirmed != true || hero.id == null) return;
    try {
      await ApiService.instance.deleteHero(hero.id!);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menghapus: $e')));
      return;
    }
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Kisah pahlawan', style: TextStyle(fontWeight: FontWeight.w900)), actions: [
      IconButton(tooltip: 'Edit pahlawan', onPressed: _edit, icon: const Icon(Icons.edit_outlined)),
      IconButton(tooltip: 'Hapus pahlawan', onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded)),
      const SizedBox(width: 10),
    ]),
    body: SafeArea(child: SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 60),
      child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1000), child: Column(children: [
        LayoutBuilder(builder: (_, constraints) {
          final compact = constraints.maxWidth < 680;
          final photo = ClipRRect(borderRadius: BorderRadius.circular(20), child: SizedBox(
            width: compact ? double.infinity : 290, height: compact ? 280 : 360,
            child: ColoredBox(color: Palette.blush, child: HeroImage(path: hero.imagePath, placeholder: 'Foto belum tersedia'))));
          final info = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TOKOH NASIONAL', style: TextStyle(color: Palette.red, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontSize: 11)),
            const SizedBox(height: 12),
            Text(hero.name, style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: compact ? 34 : 42)),
            const SizedBox(height: 21),
            _fact(Icons.place_outlined, 'Daerah asal', hero.origin),
            const SizedBox(height: 12),
            _fact(Icons.calendar_today_outlined, 'Masa hidup', hero.lifeTime),
            const SizedBox(height: 24),
            const Divider(color: Palette.line),
            const SizedBox(height: 16),
            const Text('Tentang perjuangannya', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: Palette.ink)),
            const SizedBox(height: 12),
            Text(hero.description, style: const TextStyle(color: Palette.ink, height: 1.7, fontSize: 15)),
          ]);
          return Container(width: double.infinity, padding: EdgeInsets.all(compact ? 18 : 28),
            decoration: BoxDecoration(color: Palette.paper, borderRadius: BorderRadius.circular(26), border: Border.all(color: Palette.line)),
            child: compact ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [photo, const SizedBox(height: 24), info])
              : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [photo, const SizedBox(width: 32), Expanded(child: info)]));
        }),
        if (hero.id != null) ...[const SizedBox(height: 24), CommentSection(heroId: hero.id!)],
      ]))),
    )),
  );

  Widget _fact(IconData icon, String label, String value) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, size: 19, color: Palette.red), const SizedBox(width: 11),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Palette.muted)),
      const SizedBox(height: 2), Text(value, style: const TextStyle(fontWeight: FontWeight.w700, color: Palette.ink)),
    ])),
  ]);
}
