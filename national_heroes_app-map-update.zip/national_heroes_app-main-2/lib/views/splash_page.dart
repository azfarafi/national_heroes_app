import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/palette.dart';

/// Ilustrasi peta digambar lokal, sehingga animasi tetap tersedia tanpa internet.
class SplashPage extends StatefulWidget {
  final Widget next;
  const SplashPage({super.key, required this.next});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 2300))
      ..forward().whenComplete(_finish);
  }

  void _finish() {
    if (!mounted || _leaving) return;
    _leaving = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder<void>(
      pageBuilder: (_, animation, __) => widget.next,
      transitionsBuilder: (_, animation, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut), child: child),
      transitionDuration: const Duration(milliseconds: 550),
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _finish());
    }
    return Scaffold(
      backgroundColor: Palette.cream,
      body: SafeArea(child: Stack(children: [
        Positioned(top: 16, right: 20, child: TextButton(onPressed: _finish, child: const Text('Lewati'))),
        Center(child: Padding(
          padding: const EdgeInsets.all(28),
          child: AnimatedBuilder(animation: _controller, builder: (context, _) {
            final pop = Curves.elasticOut.transform((_controller.value / .62).clamp(0.0, 1.0));
            final fade = Curves.easeOut.transform((_controller.value / .32).clamp(0.0, 1.0));
            return Column(mainAxisSize: MainAxisSize.min, children: [
              Text('ARSIP NUSANTARA  •  1945—KINI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2, color: Palette.red.withOpacity(fade))),
              const SizedBox(height: 32),
              Opacity(opacity: fade, child: Transform.scale(
                scale: math.max(.01, .65 + .35 * pop),
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 540),
                  height: 225,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFFF7E5DC), Color(0xFFFFF9EF)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    borderRadius: BorderRadius.circular(32),
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Column(children: [
                    Expanded(child: Image.asset('assets/images/indonesia_red.png', fit: BoxFit.contain)),
                    const Text('Peta: Vemaps.com', style: TextStyle(color: Palette.muted, fontSize: 10)),
                  ]),
                ),
              )),
              const SizedBox(height: 32),
              Opacity(opacity: Curves.easeOut.transform(((_controller.value - .25) / .45).clamp(0.0, 1.0)), child: Column(children: [
                Text('Jejak Pahlawan', textAlign: TextAlign.center, style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 40)),
                const SizedBox(height: 10),
                const Text('Cerita perjuangan dari seluruh penjuru Indonesia.', textAlign: TextAlign.center, style: TextStyle(color: Palette.muted, fontSize: 15)),
              ])),
            ]);
          }),
        )),
        const Positioned(bottom: 20, left: 12, right: 12, child: Center(child: Text('MENGENAL • MENGINGAT • MELANJUTKAN', textAlign: TextAlign.center, style: TextStyle(color: Palette.muted, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w700)))),
      ])),
    );
  }
}
