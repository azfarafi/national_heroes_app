import 'package:flutter/material.dart';
import '../theme/palette.dart';
import '../models/hero_model.dart';
import '../services/api_service.dart';
import '../widgets/hero_grid_card.dart';
import '../widgets/hero_tile.dart';
import 'hero_detail_page.dart';
import 'hero_form_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final _search = TextEditingController();
  List<HeroModel> _heroes = [];
  bool _loading = true;
  bool _grid = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _search.addListener(() => setState(() {}));
    _loadHeroes();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadHeroes() async {
    setState(() { _loading = true; _error = null; });
    try {
      final data = await ApiService.instance.getHeroes();
      if (!mounted) return;
      setState(() => _heroes = data);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e is ApiException ? e.message : 'Data belum dapat dimuat. Coba lagi.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<HeroModel> get _results {
    final query = _search.text.trim().toLowerCase();
    if (query.isEmpty) return _heroes;
    return _heroes.where((hero) => [hero.name, hero.origin, hero.lifeTime, hero.description]
      .any((value) => value.toLowerCase().contains(query))).toList();
  }

  Future<void> _openDetail(HeroModel hero) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => HeroDetailPage(hero: hero)));
    if (mounted) _loadHeroes();
  }

  Future<void> _openAddForm() async {
    final created = await Navigator.push<HeroModel>(context, MaterialPageRoute(builder: (_) => const HeroFormPage()));
    if (created != null && mounted) _loadHeroes();
  }

  @override
  Widget build(BuildContext context) {
    final results = _results;
    return Scaffold(
      body: SafeArea(child: RefreshIndicator(
        onRefresh: _loadHeroes,
        child: CustomScrollView(physics: const AlwaysScrollableScrollPhysics(), slivers: [
          SliverToBoxAdapter(child: _header()),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 28, 20, 100),
            sliver: SliverToBoxAdapter(child: Center(child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1140),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _feature(),
                const SizedBox(height: 34),
                _sectionHeading(),
                const SizedBox(height: 20),
                _searchField(),
                const SizedBox(height: 20),
                _resultBar(results.length),
                const SizedBox(height: 18),
                if (_loading) const Padding(padding: EdgeInsets.all(56), child: Center(child: CircularProgressIndicator()))
                else if (_error != null) _emptyState(Icons.wifi_off_rounded, 'Belum bisa memuat data', _error!, retry: true)
                else if (_heroes.isEmpty) _emptyState(Icons.auto_stories_outlined, 'Koleksi masih kosong', 'Tambahkan pahlawan pertama untuk memulai arsip ini.')
                else if (results.isEmpty) _emptyState(Icons.search_off_rounded, 'Pahlawan tidak ditemukan', 'Coba nama, daerah asal, atau kata lain dari biografinya.')
                else LayoutBuilder(builder: (context, constraints) {
                  if (!_grid) return Column(children: results.map((hero) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: HeroTile(hero: hero, onTap: () => _openDetail(hero)),
                  )).toList());
                  final width = constraints.maxWidth;
                  final columns = width < 560 ? 2 : width < 850 ? 3 : 4;
                  return GridView.builder(
                    shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns, crossAxisSpacing: 16, mainAxisSpacing: 16,
                      mainAxisExtent: width < 560 ? 252 : 298,
                    ),
                    itemCount: results.length,
                    itemBuilder: (_, index) => HeroGridCard(hero: results[index], onTap: () => _openDetail(results[index])),
                  );
                }),
              ]),
            ))),
          ),
        ]),
      )),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddForm, icon: const Icon(Icons.add_rounded), label: const Text('Tambah pahlawan', style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: Palette.red, foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }

  Widget _header() => Container(
    color: Palette.paper,
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1140), child: Row(children: [
      Container(width: 38, height: 38, decoration: BoxDecoration(color: Palette.red, borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 21)),
      const SizedBox(width: 11),
      const Expanded(child: Text('jejak pahlawan.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: -.7, color: Palette.ink))),
      IconButton(tooltip: 'Muat ulang data', onPressed: _loadHeroes, icon: const Icon(Icons.refresh_rounded)),
    ]))),
  );

  Widget _feature() => Container(
    width: double.infinity,
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFFFAE9E1), Color(0xFFF7F0E5), Color(0xFFFFFBF5)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      borderRadius: BorderRadius.circular(30), border: Border.all(color: Palette.line),
    ),
    child: LayoutBuilder(builder: (context, constraints) {
      final compact = constraints.maxWidth < 690;
      final copy = Padding(
        padding: EdgeInsets.all(compact ? 25 : 42),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: Palette.paper, borderRadius: BorderRadius.circular(99)),
            child: const Text('CERITA BANGSA  /  INDONESIA', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.3, color: Palette.darkRed))),
          const SizedBox(height: 22),
          Text('Kenali mereka.\nIngat kisahnya.', style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: compact ? 36 : 50)),
          const SizedBox(height: 16),
          const Text('Setiap nama punya cerita. Jelajahi tokoh, asal, dan jejak perjuangan yang membentuk Indonesia.',
            style: TextStyle(fontSize: 15, height: 1.6, color: Palette.muted)),
          const SizedBox(height: 23),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _smallStat('${_heroes.length}', 'tokoh dalam arsip'),
            _smallStat('∞', 'kisah inspiratif'),
          ]),
        ]),
      );
      final art = Padding(
        padding: EdgeInsets.fromLTRB(compact ? 24 : 0, 10, 24, compact ? 24 : 10),
        child: Container(height: compact ? 155 : 245, decoration: BoxDecoration(
          color: Palette.paper.withOpacity(.6), borderRadius: BorderRadius.circular(24)),
          padding: const EdgeInsets.all(16), child: Column(children: [
            Expanded(child: Image.asset('assets/images/indonesia_red.png', fit: BoxFit.contain)),
            const Text('Peta: Vemaps.com', style: TextStyle(color: Palette.muted, fontSize: 10)),
          ])),
      );
      if (compact) return Column(children: [copy, art]);
      return Row(children: [Expanded(flex: 6, child: copy), Expanded(flex: 5, child: art)]);
    }),
  );

  Widget _smallStat(String value, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
    decoration: BoxDecoration(color: Palette.paper.withOpacity(.85), borderRadius: BorderRadius.circular(12)),
    child: Text('$value  $label', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Palette.ink)),
  );

  Widget _sectionHeading() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('JELAJAHI ARSIP', style: TextStyle(fontSize: 11, color: Palette.red, fontWeight: FontWeight.w900, letterSpacing: 1.8)),
    const SizedBox(height: 6),
    Text('Para pahlawan Indonesia', style: Theme.of(context).textTheme.headlineMedium),
    const SizedBox(height: 5),
    const Text('Temukan sosok dan cerita yang ingin kamu kenal lebih dekat.', style: TextStyle(color: Palette.muted)),
  ]);

  Widget _searchField() => TextField(
    controller: _search,
    textInputAction: TextInputAction.search,
    decoration: InputDecoration(
      hintText: 'Cari nama, daerah, atau kisah pahlawan...',
      hintStyle: const TextStyle(color: Palette.muted),
      prefixIcon: const Icon(Icons.search_rounded, color: Palette.red),
      suffixIcon: _search.text.isEmpty ? null : IconButton(tooltip: 'Hapus pencarian', icon: const Icon(Icons.close_rounded), onPressed: _search.clear),
    ),
  );

  Widget _resultBar(int count) => Row(children: [
    Expanded(child: Text(_search.text.trim().isEmpty ? '$count pahlawan ditemukan' : '$count hasil untuk “${_search.text.trim()}”',
      maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, color: Palette.muted))),
    const SizedBox(width: 8),
    SegmentedButton<bool>(
      showSelectedIcon: false,
      segments: const [
        ButtonSegment(value: true, icon: Icon(Icons.grid_view_rounded), tooltip: 'Tampilan kartu'),
        ButtonSegment(value: false, icon: Icon(Icons.view_list_rounded), tooltip: 'Tampilan daftar'),
      ],
      selected: {_grid}, onSelectionChanged: (choice) => setState(() => _grid = choice.first),
    ),
  ]);

  Widget _emptyState(IconData icon, String title, String detail, {bool retry = false}) => Container(
    width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 52),
    decoration: BoxDecoration(color: Palette.paper, borderRadius: BorderRadius.circular(24), border: Border.all(color: Palette.line)),
    child: Column(children: [
      Icon(icon, size: 42, color: Palette.red), const SizedBox(height: 15),
      Text(title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 7), Text(detail, textAlign: TextAlign.center, style: const TextStyle(color: Palette.muted)),
      if (retry) ...[const SizedBox(height: 17), ElevatedButton.icon(onPressed: _loadHeroes, icon: const Icon(Icons.refresh), label: const Text('Coba lagi'))],
    ]),
  );
}
