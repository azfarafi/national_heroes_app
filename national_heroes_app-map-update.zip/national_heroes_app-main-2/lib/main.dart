import 'package:flutter/material.dart';
import 'views/dashboard_page.dart';
import 'views/splash_page.dart';
import 'theme/palette.dart';

void main() {
  runApp(const NationalHeroesApp());
}

class NationalHeroesApp extends StatelessWidget {
  const NationalHeroesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jejak Pahlawan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Palette.red, surface: Palette.paper),
        scaffoldBackgroundColor: Palette.cream,
        fontFamily: 'ArchiveSans',
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, height: 1.08, letterSpacing: -2, color: Palette.ink),
          headlineMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -1, color: Palette.ink),
          titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Palette.ink),
          bodyMedium: TextStyle(fontSize: 15, height: 1.55, color: Palette.ink),
        ),
        appBarTheme: const AppBarTheme(backgroundColor: Palette.cream, foregroundColor: Palette.ink, elevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Palette.paper,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Palette.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Palette.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Palette.red, width: 2)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
          backgroundColor: Palette.red, foregroundColor: Colors.white, elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)))),
        snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        dialogTheme: DialogThemeData(backgroundColor: Palette.paper,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
      ),
      home: const SplashPage(next: DashboardPage()),
    );
  }
}
